preferred_syntax = :sass
css_dir = 'css'
sass_dir = 'sass'
images_dir = 'images'
javascripts_dir = 'js'
relative_assets = true
line_comments = false
# output_style = :compressed