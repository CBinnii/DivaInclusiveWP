<?php
/**
 * Theme Functions
 */

// Removing the admin bar
remove_action('init', 'wp_admin_bar_init');
